/**
 * 性别枚举
 */
export const USER_GENDER_ENUM = {
  0: '男',
  1: '女',
};

/**
 * 工作状态
 */
export const USER_JOB_STATUS_ENUM = {
  0: '在学校',
  1: '求职中',
  2: '已工作',
};

// 最大兴趣数
export const MAX_INTERESTS_NUM = 20;
