function e(){localStorage.removeItem("token"),sessionStorage.removeItem("isValid")}export{e as c};
