import mongoose from "mongoose";

/* 定义upload模型结构 */
const uploadSchema = new mongoose.Schema({});

export default uploadSchema;
